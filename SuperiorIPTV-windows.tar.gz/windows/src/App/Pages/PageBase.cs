namespace SuperiorIptv.Win;

/// <summary>Base class of the screens shown next to the navigation rail.</summary>
public abstract class PageBase : Control
{
    protected readonly AppServices App;
    protected int HeaderHeight => Theme.S(58);

    protected PageBase(AppServices app)
    {
        App = app;
        BackColor = Theme.Background;
        SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
    }

    /// <summary>The page became visible.</summary>
    public virtual void OnShown() { }

    /// <summary>The page was replaced by another one.</summary>
    public virtual void OnHidden() { }

    /// <summary>Called about twice a second while the page is visible.</summary>
    public virtual void OnTick() { }

    /// <summary>Playlists, favourites or the guide changed.</summary>
    public virtual void OnLibraryChanged() { }

    protected abstract void Arrange();

    /// <summary>Lays the page out again (called when it becomes visible).</summary>
    public void Relayout()
    {
        if (Width > 0 && Height > 0) Arrange();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        if (Width > 0 && Height > 0) Arrange();
    }

    protected void DrawHeader(Graphics g, int x, string title, string subtitle)
    {
        int titleWidth = Theme.MeasureWidth(g, title, Theme.Ui(14f, FontStyle.Bold));
        Theme.DrawText(g, title, Theme.Ui(14f, FontStyle.Bold), Theme.Text, new Rectangle(x, 0, titleWidth + Theme.S(4), HeaderHeight));
        if (!string.IsNullOrEmpty(subtitle))
        {
            Theme.DrawText(g, subtitle, Theme.Ui(9.5f), Theme.Secondary, new Rectangle(x + titleWidth + Theme.S(14), Theme.S(3), Math.Max(10, Width - x - titleWidth - Theme.S(20)), HeaderHeight));
        }
    }

    /// <summary>Places buttons right-aligned in the header, last one at the far right.</summary>
    protected void PlaceHeaderButtons(params FlatButton[] buttons)
    {
        int x = Width - Theme.S(14);
        for (int i = buttons.Length - 1; i >= 0; i--)
        {
            FlatButton button = buttons[i];
            if (!button.Shown) continue;
            int width = button.PreferredWidth();
            x -= width;
            button.SetBounds(x, Theme.S(11), width, Theme.S(36));
            x -= Theme.S(8);
        }
    }
}

/// <summary>Dialogs that several screens open.</summary>
public static class Sheets
{
    /// <summary>
    /// "Record…" options for a channel. While the channel is already being recorded the sheet stays
    /// available: it then offers to stop that recording or to schedule further ones.
    /// </summary>
    public static void Record(IWin32Window owner, AppServices app, Channel channel)
    {
        using ActionDialog dialog = RecordDialog(owner, app, channel);
        dialog.ShowDialog(owner);
    }

    public static ActionDialog RecordDialog(IWin32Window owner, AppServices app, Channel channel)
    {
        DateTime now = DateTime.UtcNow;
        Programme current = app.Library.Epg.Current(channel, now);
        Recording active = app.Recordings.ActiveFor(channel.Id);
        List<Recording> booked = app.Recordings.ScheduledFor(channel.Id);
        string note = active != null
            ? $"This channel is being recorded until {Theme.Time(active.End)}. You can schedule more recordings of it; each one is saved as its own file."
            : "If the stream drops, recording reconnects and carries on by itself until the end time. "
              + (app.Settings.AutoConvertMp4 ? "The file is converted to MP4 when it finishes." : "The file is saved as .ts; convert it to MP4 from Recordings.");
        var dialog = new ActionDialog("Record " + channel.Name, "", note);

        if (active != null)
        {
            dialog.AddAction($"Stop the recording in progress ({active.Title})", Theme.Glyph.Stop, () => app.Recordings.Stop(active.Id), Theme.Live);
        }
        else
        {
            if (current != null)
            {
                DateTime end = current.Stop.AddMinutes(app.Settings.PadAfterMinutes);
                dialog.AddAction($"This programme: {current.Title} (until {Theme.Time(current.Stop)})", Theme.Glyph.Record,
                    () => app.RecordNow(channel, current.Title, end), Theme.Live);
            }
            foreach (int minutes in new[] { 30, 60, 120, 180, 240 })
            {
                string label = minutes < 60 ? $"{minutes} minutes" : minutes == 60 ? "1 hour" : $"{minutes / 60} hours";
                int captured = minutes;
                dialog.AddAction($"{label} (until {Theme.Time(now.AddMinutes(minutes))})", Theme.Glyph.Record,
                    () => app.RecordNow(channel, current?.Title ?? channel.Name, DateTime.UtcNow.AddMinutes(captured)), Theme.Live);
            }
        }

        // Coming up on this channel: one click books a programme. Any number can be booked.
        int offered = 0;
        foreach (Programme programme in app.Library.Epg.Upcoming(channel, now, 8))
        {
            if (offered >= (active != null ? 5 : 3)) break;
            if (app.Recordings.IsScheduled(channel.Id, programme.Start)) continue;
            Programme upcoming = programme;
            dialog.AddAction($"Schedule: {programme.Title} ({TimeText.DayTime(programme.Start.ToLocalTime())} – {Theme.Time(programme.Stop)})", Theme.Glyph.Clock, () =>
            {
                app.Recordings.Schedule(channel, upcoming, app.Library.UserAgentFor(channel.PlaylistId, channel));
                app.Toast("Recording scheduled: " + upcoming.Title);
            });
            offered++;
        }
        dialog.AddAction(active != null ? "Schedule at a custom time: choose when it starts and ends…" : "Custom time: choose when it starts and ends…", Theme.Glyph.Clock, () =>
        {
            using var custom = new RecordTimeDialog(app, channel, active != null ? null : current);
            custom.ShowDialog(owner);
        });

        if (booked.Count > 0)
        {
            string list = string.Join("; ", booked.Take(4).Select(r => $"{r.Title}, {TimeText.DayTime(r.Start.ToLocalTime())} – {Theme.Time(r.End)}"));
            dialog.AddNote($"Already scheduled on this channel ({booked.Count}): {list}{(booked.Count > 4 ? "; …" : "")}. Bookings can be cancelled in Recordings.", Theme.Good);
        }
        dialog.AddClose("Cancel");
        return dialog;
    }

    /// <summary>Lets the viewer choose which guide source one channel takes its listings from.</summary>
    public static void GuideSource(IWin32Window owner, AppServices app, Channel channel)
    {
        using ActionDialog dialog = GuideSourceDialog(app, channel);
        dialog.ShowDialog(owner);
    }

    public static ActionDialog GuideSourceDialog(AppServices app, Channel channel)
    {
        GuideBook guide = app.Library.Epg;
        GuideChoice chosen = guide.ChoiceFor(channel);
        bool hasAdditional = guide.HasAdditional(channel);
        bool inPrimary = guide.ListFrom(channel, false).Count > 0, inAdditional = guide.ListFrom(channel, true).Count > 0;
        string inUse = guide.ListFor(channel).Count == 0 ? "No listings are shown for this channel at the moment."
            : guide.UsesAdditional(channel) ? "Its listings currently come from the additional guide."
            : "Its listings currently come from the primary guide.";
        var dialog = new ActionDialog("Guide source", channel.Name,
            inUse + " The primary and additional guide addresses are set per playlist in Settings, under Playlists.");

        string Mark(GuideChoice choice) => choice == chosen ? "   ✓" : "";
        string Has(bool listed) => listed ? "has listings for this channel" : "no listings for this channel";
        void Choose(GuideChoice choice, string said)
        {
            app.Library.SetGuideChoice(channel, choice);
            app.Toast(channel.Name + ": " + said);
        }

        dialog.AddAction("Automatic (primary guide first, then additional)" + Mark(GuideChoice.Automatic), Theme.Glyph.Refresh,
            () => Choose(GuideChoice.Automatic, "guide source chosen automatically"));
        dialog.AddAction($"Primary guide ({Has(inPrimary)})" + Mark(GuideChoice.Primary), Theme.Glyph.Guide,
            () => Choose(GuideChoice.Primary, "using the primary guide"));
        if (hasAdditional)
        {
            dialog.AddAction($"Additional guide ({Has(inAdditional)})" + Mark(GuideChoice.Additional), Theme.Glyph.Guide,
                () => Choose(GuideChoice.Additional, "using the additional guide"));
        }
        else
        {
            dialog.AddNote("This channel's playlist has no additional guide yet. Add one in Settings, under Playlists.");
        }
        dialog.AddAction("No guide for this channel" + Mark(GuideChoice.None), Theme.Glyph.Close,
            () => Choose(GuideChoice.None, "guide switched off"));
        dialog.AddClose("Cancel");
        return dialog;
    }

    /// <summary>Details of a guide entry with whatever can be done with it right now.</summary>
    public static void Programme(IWin32Window owner, AppServices app, Channel channel, Programme programme)
    {
        DateTime now = DateTime.UtcNow;
        string when = TimeText.ShortDate(programme.Start.ToLocalTime()) + " · " + Theme.Range(programme);
        var dialog = new ActionDialog(programme.Title, channel.Name + " · " + when, programme.Desc);

        if (programme.IsLive(now))
        {
            dialog.AddAction("Watch live", Theme.Glyph.Play, () => app.Watch(channel));
            if (Catchup.IsAvailable(channel, programme, now)) dialog.AddAction("Watch from the start", Theme.Glyph.Catchup, () => PlayCatchup(app, channel, programme));
            Recording active = app.Recordings.ActiveFor(channel.Id);
            if (active != null)
            {
                dialog.AddAction("Stop recording", Theme.Glyph.Stop, () => app.Recordings.Stop(active.Id), Theme.Live);
            }
            else
            {
                dialog.AddAction("Record until it ends", Theme.Glyph.Record,
                    () => app.RecordNow(channel, programme.Title, programme.Stop.AddMinutes(app.Settings.PadAfterMinutes)), Theme.Live);
            }
        }
        else if (programme.Start > now)
        {
            if (app.Recordings.IsScheduled(channel.Id, programme.Start))
            {
                dialog.AddNote("A recording is scheduled for this programme.", Theme.Good);
            }
            else
            {
                dialog.AddAction("Schedule recording", Theme.Glyph.Record, () =>
                {
                    app.Recordings.Schedule(channel, programme, app.Library.UserAgentFor(channel.PlaylistId, channel));
                    app.Toast("Recording scheduled: " + programme.Title);
                }, Theme.Live);
                dialog.AddNote("Keep Superior IPTV Player running at the scheduled time (it can be minimised).");
            }
        }
        else if (Catchup.IsAvailable(channel, programme, now))
        {
            dialog.AddAction("Watch (catch-up)", Theme.Glyph.Catchup, () => PlayCatchup(app, channel, programme));
        }
        else
        {
            dialog.AddNote("This programme has ended and the channel does not offer catch-up.");
        }
        dialog.AddClose();
        using (dialog) dialog.ShowDialog(owner);
    }

    private static void PlayCatchup(AppServices app, Channel channel, Programme programme)
    {
        PlayableItem item = app.Library.PlayableCatchup(channel, programme);
        if (item == null) app.Toast("Catch-up is not available for this programme.");
        else app.PlayItem(item);
    }

    /// <summary>Movie details: play, resume, download.</summary>
    public static async void Movie(Control owner, AppServices app, Movie movie)
    {
        var info = new XtreamVodInfo();
        if (movie.XtreamId != null)
        {
            XtreamClient client = app.Library.XtreamFor(movie.PlaylistId);
            if (client != null)
            {
                owner.Cursor = Cursors.WaitCursor;
                try
                {
                    using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));
                    info = await client.MovieInfoAsync(movie.XtreamId.Value, cts.Token);
                }
                catch (Exception)
                {
                    // Details are optional; the movie can still be played and downloaded.
                }
                owner.Cursor = Cursors.Default;
                if (owner.IsDisposed) return;
            }
        }

        string year = string.IsNullOrEmpty(movie.Year) ? info.Year : movie.Year;
        string rating = string.IsNullOrEmpty(movie.Rating) ? info.Rating : movie.Rating;
        string facts = string.Join(" · ", new[] { year, info.Genre, info.Duration, string.IsNullOrEmpty(rating) ? "" : "★ " + rating }.Where(s => !string.IsNullOrEmpty(s)));
        var dialog = new ActionDialog(movie.Name, facts, string.IsNullOrEmpty(info.Plot) ? movie.Plot : info.Plot, movie.Poster);

        long resumeAt = app.Resume.Get(movie.Id);
        DownloadItem download = app.Downloads.FindBySource(movie.Id);
        bool local = app.LocalCopy(movie.Id) != null;
        if (resumeAt > 0)
        {
            dialog.AddAction("Resume from " + Theme.Clock(resumeAt), Theme.Glyph.Play, () => app.PlayMovie(movie));
            dialog.AddAction("Play from the beginning", Theme.Glyph.Refresh, () =>
            {
                app.Resume.Set(movie.Id, 0);
                app.PlayMovie(movie);
            });
        }
        else
        {
            dialog.AddAction(local ? "Play (downloaded copy)" : "Play", Theme.Glyph.Play, () => app.PlayMovie(movie));
        }

        if (download == null)
        {
            dialog.AddAction("Download", Theme.Glyph.Download, () =>
            {
                app.Download(movie);
                app.Toast("Added to Downloads: " + movie.Name);
            });
        }
        else if (download.State == DownloadState.Completed)
        {
            dialog.AddNote("Downloaded to " + download.FilePath, Theme.Good);
        }
        else
        {
            dialog.AddAction($"Downloading ({download.State}, {download.Fraction:P0}): open Downloads", Theme.Glyph.Download, () => app.GoTo("downloads"));
        }
        dialog.AddClose();
        using (dialog) dialog.ShowDialog(owner);
    }

    public static void ShowInFolder(string path)
    {
        try
        {
            if (File.Exists(path)) System.Diagnostics.Process.Start("explorer.exe", "/select,\"" + path + "\"");
            else if (Directory.Exists(Path.GetDirectoryName(path))) OpenFolder(Path.GetDirectoryName(path));
        }
        catch (Exception)
        {
        }
    }

    public static void OpenFolder(string folder)
    {
        try
        {
            Directory.CreateDirectory(folder);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", "\"" + folder + "\"") { UseShellExecute = true });
        }
        catch (Exception)
        {
        }
    }
}
