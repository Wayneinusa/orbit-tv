import SwiftUI

/// Everything the app keeps alive for its whole lifetime. Created lazily by SwiftUI once the app is running.
@MainActor
final class AppServices: ObservableObject {
    let settings: AppSettings
    let model: AppModel
    let epg: EPGModel
    let player: PlayerController
    let recordings: RecordingManager
    let router: AppRouter

    init() {
        let settings = AppSettings()
        let model = AppModel(settings: settings)
        let player = PlayerController(settings: settings)
        let router = AppRouter()
        router.attach(model: model, player: player)
        self.settings = settings
        self.model = model
        self.epg = EPGModel()
        self.player = player
        self.recordings = RecordingManager(settings: settings)
        self.router = router
    }
}

@main
struct OrbitTVApp: App {
    #if os(iOS)
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    #endif
    @StateObject private var services = AppServices()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(services.settings)
                .environmentObject(services.model)
                .environmentObject(services.epg)
                .environmentObject(services.player)
                .environmentObject(services.recordings)
                .environmentObject(services.router)
                .preferredColorScheme(.dark)
                .onChange(of: scenePhase) { phase in
                    // Coming back to the foreground: restart anything that was cut off while suspended.
                    if phase == .active { services.recordings.tick() }
                }
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var epg: EPGModel
    @EnvironmentObject private var player: PlayerController
    @EnvironmentObject private var recordings: RecordingManager
    @EnvironmentObject private var router: AppRouter

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()

            if !model.didBootstrap {
                ProgressView()
            } else if model.playlists.isEmpty {
                OnboardingView()
            } else {
                HStack(spacing: 0) {
                    SideRail()
                    sectionView
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                .opacity(router.fullscreen ? 0 : 1)
                .disabled(router.fullscreen)
                .overlayPreferenceValue(PreviewAnchorKey.self) { anchor in
                    MainVideoLayer(previewAnchor: anchor)
                }

                if router.fullscreen {
                    PlayerScreen()
                }
            }

            StatusBanner()
        }
        .task {
            await model.bootstrap()
            await epg.loadCache()
            await epg.refreshIfNeeded(model: model, settings: settings)
            // Keep the guide fresh when the app stays open for days (typical on an Apple TV).
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_800_000_000_000)
                await epg.refreshIfNeeded(model: model, settings: settings)
            }
        }
        .onChange(of: model.channels.count) { _ in
            guard model.didBootstrap else { return }
            Task { await epg.refreshIfNeeded(model: model, settings: settings) }
        }
        .onReceive(player.$item) { item in
            recordings.keepAwakeForPlayback = item != nil
        }
    }

    @ViewBuilder
    private var sectionView: some View {
        switch router.section {
        case .live: LiveTVView()
        case .guide: GuideView()
        case .movies: MoviesView()
        case .series: SeriesView()
        case .recordings: RecordingsView()
        case .multiview: MultiViewScreen()
        case .search: SearchView()
        case .settings: SettingsView()
        }
    }
}

// MARK: - The main player's picture

/// Reports where the Live TV preview box is, so the video surface can be placed over it.
struct PreviewAnchorKey: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }

    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        if let next = nextValue() { value = next }
    }
}

/// The one and only surface of the main player. It sits above the sections and below the full-screen
/// controls, and is resized between the preview box and the whole screen. It is never taken out of the
/// view tree and the video view is never handed to another surface: doing that mid-playback left the
/// full-screen picture black on iPad while the sound carried on.
struct MainVideoLayer: View {
    @EnvironmentObject private var router: AppRouter
    @EnvironmentObject private var player: PlayerController
    @ObservedObject private var external = ExternalDisplay.shared
    let previewAnchor: Anchor<CGRect>?

    var body: some View {
        GeometryReader { proxy in
            let full = router.fullscreen
            let onTV = external.isConnected
            let preview: CGRect? = previewAnchor.map { proxy[$0] }
            let rect: CGRect = full
                ? CGRect(origin: .zero, size: proxy.size)
                : (preview ?? CGRect(x: 0, y: 0, width: 8, height: 8))
            let visible = player.item != nil && (full || preview != nil)

            ZStack(alignment: .topLeading) {
                Color.black.opacity(full ? 1 : 0)
                PlayerSurface(controller: player, detached: onTV)
                    .frame(width: max(8, rect.width), height: max(8, rect.height))
                    .overlay(onTVNote(shown: onTV, large: full))
                    .overlay(previewStatus(full: full))
                    .clipShape(RoundedRectangle(cornerRadius: full ? 0 : Theme.corner, style: .continuous))
                    .offset(x: rect.minX, y: rect.minY)
                    .opacity(visible ? 1 : 0)
            }
            .frame(width: proxy.size.width, height: proxy.size.height, alignment: .topLeading)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .onAppear { route(external.isConnected, moved: false) }
        .onChange(of: external.isConnected) { connected in route(connected, moved: true) }
        .onChange(of: player.item?.id) { _ in external.setPlaying(player.item != nil) }
    }

    /// Sends the picture to the TV when one is connected through AirPlay, and takes it back afterwards.
    private func route(_ toTV: Bool, moved: Bool) {
        if toTV { external.show(player.videoView) }
        external.setPlaying(player.item != nil)
        // The picture changed screens while playing: start it again so that VLC draws in its new place.
        if moved && player.item != nil {
            let controller = player
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 300_000_000)
                controller.restart()
            }
        }
    }

    @ViewBuilder
    private func onTVNote(shown: Bool, large: Bool) -> some View {
        if shown {
            VStack(spacing: large ? 12 : 6) {
                Image(systemName: "airplayvideo").font(.system(size: large ? 54 : 26))
                Text("Playing on the TV").font(large ? .title3 : .footnote)
            }
            .foregroundColor(Theme.secondaryText)
        }
    }

    /// Spinner and error text for the preview. Full screen has its own, drawn by PlayerScreen.
    @ViewBuilder
    private func previewStatus(full: Bool) -> some View {
        if !full {
            if player.status == .loading {
                ProgressView()
            } else if player.status == .failed || player.status == .ended {
                Text("This channel is not responding").font(.footnote).foregroundColor(Theme.secondaryText)
            }
        }
    }
}

// MARK: - Navigation rail

struct SideRail: View {
    @EnvironmentObject private var router: AppRouter
    @EnvironmentObject private var recordings: RecordingManager

    var body: some View {
        VStack(spacing: Theme.isTV ? 14 : 6) {
            ForEach(AppRouter.Section.allCases) { section in
                Button {
                    router.section = section
                } label: {
                    VStack(spacing: 4) {
                        ZStack(alignment: .topTrailing) {
                            Image(systemName: section.symbol)
                                .font(.system(size: Theme.isTV ? 30 : 20, weight: .semibold))
                            if section == .recordings && recordings.recordings.contains(where: { $0.status == .recording }) {
                                Circle().fill(Theme.live).frame(width: 9, height: 9).offset(x: 8, y: -4)
                            }
                        }
                        Text(section.title).font(.caption2).lineLimit(1).minimumScaleFactor(0.7)
                    }
                    .frame(width: Theme.railWidth - 16, height: Theme.isTV ? 84 : 54)
                }
                .buttonStyle(TileButtonStyle(selected: router.section == section))
            }
            Spacer(minLength: 0)
            TimelineView(.periodic(from: Date(), by: 20)) { context in
                Text(Format.time.string(from: context.date))
                    .font(.caption)
                    .foregroundColor(Theme.secondaryText)
            }
        }
        .padding(.vertical, Theme.pad)
        .frame(width: Theme.railWidth)
        .background(Theme.panel)
        #if os(tvOS)
        .focusSection()
        #endif
    }
}

/// Thin strip at the top for "loading…" and error messages.
struct StatusBanner: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack {
            if !model.busyText.isEmpty {
                HStack(spacing: 10) {
                    ProgressView()
                    Text(model.busyText).font(.footnote)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(Capsule().fill(Theme.raised))
            } else if !model.errorText.isEmpty && !model.playlists.isEmpty {
                Button {
                    model.errorText = ""
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.yellow)
                        Text(model.errorText).font(.footnote).lineLimit(2)
                        Image(systemName: "xmark").font(.caption)
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                }
                .buttonStyle(TileButtonStyle(fill: Theme.raised))
            }
            Spacer()
        }
        .padding(.top, 12)
        .foregroundColor(.white)
    }
}

// MARK: - First run

struct OnboardingView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Image(systemName: "dot.radiowaves.left.and.right")
                    .font(.system(size: Theme.isTV ? 80 : 54))
                    .foregroundColor(Theme.accent)
                Text("Welcome to Superior IPTV Player").font(.largeTitle.bold()).foregroundColor(.white)
                Text("Add the playlist from your TV provider to get started. Superior IPTV Player is a player only and does not include any channels.")
                    .font(.body)
                    .foregroundColor(Theme.secondaryText)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 700)
                PlaylistEditor(existing: nil, onDone: {})
                    .frame(maxWidth: Theme.isTV ? 1100 : 640)
            }
            .padding(40)
            .frame(maxWidth: .infinity)
        }
    }
}

struct PlaylistEditor: View {
    @EnvironmentObject private var model: AppModel
    let existing: Playlist?
    var onDone: () -> Void

    @State private var kind = 0
    @State private var name = ""
    @State private var server = ""
    @State private var username = ""
    @State private var password = ""
    @State private var address = ""
    @State private var epgURL = ""
    @State private var userAgent = ""
    @State private var working = false
    @State private var loaded = false

    var body: some View {
        VStack(alignment: .leading, spacing: Theme.isTV ? 22 : 14) {
            Picker("Playlist type", selection: $kind) {
                Text("Xtream Codes login").tag(0)
                Text("M3U address").tag(1)
            }
            .pickerStyle(.segmented)

            EntryField(title: "Name", prompt: "My TV", text: $name)
            if kind == 0 {
                EntryField(title: "Server", prompt: "http://example.com:8080", text: $server, isAddress: true)
                EntryField(title: "Username", prompt: "", text: $username, isAddress: true)
                EntryField(title: "Password", prompt: "", text: $password, isAddress: true, isSecret: true)
            } else {
                EntryField(title: "M3U address", prompt: "http://example.com/playlist.m3u", text: $address, isAddress: true)
            }
            EntryField(title: "Guide (XMLTV) address, optional", prompt: "Leave empty to use the playlist's own", text: $epgURL, isAddress: true)
            EntryField(title: "User-Agent, optional", prompt: "Leave empty unless your provider requires one", text: $userAgent, isAddress: true)

            if !model.errorText.isEmpty {
                Text(model.errorText).font(.footnote).foregroundColor(.yellow)
            }

            HStack(spacing: 14) {
                Button {
                    Task { await save() }
                } label: {
                    HStack {
                        if working { ProgressView() }
                        Text(working ? "Loading…" : (existing == nil ? "Add playlist" : "Save and reload"))
                            .fontWeight(.semibold)
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                }
                .buttonStyle(TileButtonStyle(fill: Theme.accent.opacity(0.85)))
                .disabled(working || !isValid)

                if existing != nil {
                    Button {
                        onDone()
                    } label: {
                        Text("Cancel").padding(.horizontal, 24).padding(.vertical, 12)
                    }
                    .buttonStyle(TileButtonStyle(fill: Theme.raised))
                }
            }
        }
        .padding(Theme.pad * 1.5)
        .background(RoundedRectangle(cornerRadius: Theme.corner).fill(Theme.panel))
        .onAppear(perform: fill)
    }

    private var isValid: Bool {
        if kind == 0 { return !server.isEmpty && !username.isEmpty && !password.isEmpty }
        return address.contains("://")
    }

    private func fill() {
        guard !loaded, let playlist = existing else { return }
        loaded = true
        name = playlist.name
        epgURL = playlist.epgURL
        userAgent = playlist.userAgent
        switch playlist.source {
        case .xtream(let savedServer, let savedUser, let savedPassword):
            kind = 0
            server = savedServer
            username = savedUser
            password = savedPassword
        case .m3u(let url):
            kind = 1
            address = url
        }
    }

    private func save() async {
        working = true
        defer { working = false }
        let trimmedName = name.trimmingCharacters(in: .whitespaces)
        let source: PlaylistSource = kind == 0
            ? .xtream(server: server.trimmingCharacters(in: .whitespaces),
                      username: username.trimmingCharacters(in: .whitespaces),
                      password: password.trimmingCharacters(in: .whitespaces))
            : .m3u(url: address.trimmingCharacters(in: .whitespaces))

        var playlist = existing ?? Playlist(name: "", source: source)
        playlist.name = trimmedName.isEmpty ? (kind == 0 ? "Xtream playlist" : "M3U playlist") : trimmedName
        playlist.source = source
        playlist.epgURL = epgURL.trimmingCharacters(in: .whitespaces)
        playlist.userAgent = userAgent.trimmingCharacters(in: .whitespaces)

        let succeeded: Bool
        if existing == nil {
            succeeded = await model.add(playlist)
        } else {
            succeeded = await model.update(playlist)
        }
        if succeeded { onDone() }
    }
}

/// Text entry that behaves on both platforms (the Apple TV shows its full-screen keyboard).
struct EntryField: View {
    let title: String
    let prompt: String
    @Binding var text: String
    var isAddress = false
    var isSecret = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundColor(Theme.secondaryText)
            field
                .textInputAutocapitalization(capitalization)
                .autocorrectionDisabled(true)
                #if os(iOS)
                .keyboardType(isAddress && !isSecret ? .URL : .default)
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 8).fill(Color.white.opacity(0.08)))
                .foregroundColor(.white)
                #endif
        }
    }

    private var capitalization: TextInputAutocapitalization {
        isAddress ? TextInputAutocapitalization.never : TextInputAutocapitalization.words
    }

    @ViewBuilder
    private var field: some View {
        if isSecret {
            SecureField(prompt, text: $text)
        } else {
            TextField(prompt, text: $text)
        }
    }
}
